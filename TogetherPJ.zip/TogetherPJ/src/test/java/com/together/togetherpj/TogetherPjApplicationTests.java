package com.together.togetherpj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TogetherPjApplicationTests {

    @Test
    void contextLoads() {
    }

}
