package com.together.togetherpj.member.constant;

public enum Role {
  MEMBER, ADMIN
}
