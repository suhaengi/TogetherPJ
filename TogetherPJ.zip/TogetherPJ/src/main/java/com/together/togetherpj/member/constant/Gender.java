package com.together.togetherpj.member.constant;

public enum Gender {
  MALE, FEMALE
}
